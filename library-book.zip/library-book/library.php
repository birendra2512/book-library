<?php

/**
 * Plugin Name: Library Book
 * Plugin URI: 
 * Description: Library Book search plugin. shortcode : [book-library]
 * Version: 1.0
 * Author: Birendra
 * Author URI: 
 * */

define( 'RLS_VERSION' , '1.0.0' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-rls.php';

require plugin_dir_path( __FILE__ ) . 'includes/class-meta-rls.php';

require plugin_dir_path( __FILE__ ) . 'includes/class-short-code-rls.php';

require plugin_dir_path( __FILE__ ) . 'includes/custom-functions.php';





