<?php
get_header();

/* Start the Loop */
while (have_posts()) :
    the_post();
    ?>

    <div id="content" class="site-content">
        <div id="primary" class="content-area">
            <main id="main" class="site-main">

                <article class="entry">
                    <div class="entry-content">
                        <h4><strong>Book Name :</strong> WINGS OF FIRE</h4>
                        <h4><strong>Author : </strong><?php
                            $term_list = get_the_terms($post->ID, 'author');
                            $types = '';
                            foreach ($term_list as $term_single) {
                                $types .= ucfirst($term_single->slug) . ', ';
                            }
                            $author = rtrim($types, ', ');
                            echo $author;
                            ?></h4>
                        <h4><strong>Publisher : </strong><?php
                            $term_list = get_the_terms($post->ID, 'publisher');
                            $types = '';
                            foreach ($term_list as $term_single) {
                                $types .= ucfirst($term_single->slug) . ', ';
                            }
                            $publisher = rtrim($types, ', ');
                            echo $publisher;
                            ?></h4>
                        <h4><strong>Description : </strong></h4><?php the_content(); ?>
                        <h4><strong>Rating : </strong><?php $rating = get_post_meta(get_the_ID(), 'books_rating', true); ?> 
                            <span class="fa fa-star <?php
                            if ($rating > 0) {
                                echo 'checked';
                            }
                            ?>"></span>
                            <span class="fa fa-star <?php
                            if ($rating > 1) {
                                echo 'checked';
                            }
                            ?>"></span>
                            <span class="fa fa-star <?php
                            if ($rating > 2) {
                                echo 'checked';
                            }
                            ?>"></span>
                            <span class="fa fa-star <?php
                            if ($rating > 3) {
                                echo 'checked';
                            }
                            ?>"></span>
                            <span class="fa fa-star <?php
                                  if ($rating > 4) {
                                      echo 'checked';
                                  }
                                  ?>"></span></h4>
                        <h4><strong>Price : </strong><?php echo $price = get_post_meta(get_the_ID(), 'books_price', true); ?></h4>
                    </div>
                </article>
            </main>
        </div>
    </div>
    <?php
endwhile;
wp_reset_postdata();
get_footer();
