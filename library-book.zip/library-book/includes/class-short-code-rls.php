<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
class SHORTCODERls {

    public function __construct() {
        add_shortcode('book-library', array($this, 'book_library_the_shortcode_func'));
    }

    public function book_library_the_shortcode_func($atts) {
        $attributes = shortcode_atts(array(
            'title' => false,
            'limit' => 4,
                ), $atts);

        ob_start();
        ?>
        <style>
            .checked {
                color: orange;
            }
        </style>
        <form method = "POST" id = "filter">
            <div class ="row">
                <label for = "book">Book Name : </label>
                <input type = "text" name = "book_name" placeholder = "Book name" />
                <label for = "author">Author :</label>
                <?php
                if ($terms = get_terms(array('taxonomy' => 'author', 'orderby' => 'name'))) :

                    echo '<select name="author"><option value="">Select author</option>';
                    foreach ($terms as $term) :
                        echo '<option value="' . $term->term_id . '">' . $term->name . '</option>'; // ID of the category as the value of an option
                    endforeach;
                    echo '</select>';
                endif;
                ?>
            </div>
            <div class="row">
                <label for="publisher">Publisher</label>
                <?php
                if ($terms = get_terms(array('taxonomy' => 'publisher', 'orderby' => 'name'))) :

                    echo '<select name="publisher"><option value="">Select Publisher</option>';
                    foreach ($terms as $term) :
                        echo '<option value="' . $term->term_id . '">' . $term->name . '</option>'; // ID of the category as the value of an option
                    endforeach;
                    echo '</select>';
                endif;
                ?>
                <label for="rating">Rating</label>
                <select name="rating" id="rating">
                    <option value="">Rating</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                </select>
            </div>
            <div class="row">
                <label for="price">Price (between 1000 and 3000):</label>
                <input type="range" id="price" name="price" min="1000" max="3000" style="width: 20%"  oninput="priceoutput.value = price.value">
                <output name="priceoutput" id="priceoutput">3000</output>
            </div>
            <button>Apply filter</button>
            <input type="hidden" name="action" value="myfilter">
        </form>
        <div id="response"></div>
        <?php
        return ob_get_clean();
    }

}
function run_shortrls() {

    $short_rlsplugin = new SHORTCODERls();
    return $short_rlsplugin;
}

run_shortrls();
?>