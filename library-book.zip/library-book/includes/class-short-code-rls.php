<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}

class SHORTCODERls {

    public function __construct() {
        add_shortcode('book-library', array($this, 'book_library_the_shortcode_func'));
    }

    public function book_library_the_shortcode_func($atts) {
        $attributes = shortcode_atts(array(
            'title' => false,
            'limit' => 4,
                ), $atts);

        ob_start();
        ?>
        <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
        <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
        <h4>Book Search</h4>
        <form method = "POST" id = "filter">
            <div class ="row">
                <label for = "book">Book Name : </label>

                <input type = "text" name = "book_name" placeholder = "Book name" style="width: 27%;"/>

                <label for = "author">Author :</label>
                <?php
                if ($terms = get_terms(array('taxonomy' => 'author', 'orderby' => 'name'))) :

                    echo '<select name="author"><option value="">Select author</option>';
                    foreach ($terms as $term) :
                        echo '<option value="' . $term->term_id . '">' . $term->name . '</option>'; // ID of the category as the value of an option
                    endforeach;
                    echo '</select>';
                endif;
                ?>

            </div>
            <div class="row">

                <label for="publisher">Publisher :</label>
                <?php
                if ($terms = get_terms(array('taxonomy' => 'publisher', 'orderby' => 'name'))) :

                    echo '<select name="publisher"><option value="">Select Publisher</option>';
                    foreach ($terms as $term) :
                        echo '<option value="' . $term->term_id . '">' . $term->name . '</option>'; // ID of the category as the value of an option
                    endforeach;
                    echo '</select>';
                endif;
                ?>

                <label for="rating">Rating :</label>
                <select name="rating" id="rating">
                    <option value="">Rating</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                </select>
            </div>

            <div class="row">
                <div class="cs-widget">
                    <label for="rating">Price:
                        <div class="cs-widget-content">
                            <div id="slider-container"></div>
                            <span class="min-value"></span>
                            <span class="max-value"></span>
                            <p class="clearfix">
                                <input type="hidden" id="amount" name="amount" class="price-range" />
                            </p>
                            <div id="slider-range"></div>
                        </div>
                </div><!-- comment -->
            </div>
            <div class="row button-div">
                <button>Search</button>
                <input type="hidden" name="action" value="myfilter">
            </div>
        </form>
        <div id="response"></div>
        <?php
        return ob_get_clean();
    }

}

function run_shortrls() {
    $short_rlsplugin = new SHORTCODERls();
    return $short_rlsplugin;
}

run_shortrls();
?>