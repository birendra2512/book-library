<?php

// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
function custom_assets_files() {
    // wp_enqueue_stylesheets/jquery
    $protocol = '';
    wp_enqueue_style('font-awsome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), null, 'all'); 
    wp_enqueue_script('ajax_call', plugin_dir_url( __FILE__)  . '/assets/ajax_function.js', array(), '1.0.0', true);
    $params = array(
        'ajaxurl' => admin_url('admin-ajax.php', $protocol),
        'ajax_nonce' => wp_create_nonce('custom_woo_nonce_field'),
    );
    wp_localize_script('ajax_call', 'ajax_object', $params);
   
}

add_action('wp_enqueue_scripts', 'custom_assets_files');

add_action('wp_ajax_myfilter', 'custom_filter_function'); // wp_ajax_{ACTION HERE} 
add_action('wp_ajax_nopriv_myfilter', 'custom_filter_function');

function custom_filter_function() {
    $book_name = $_POST['book_name'];
    $author = $_POST['author'];
    $publisher = $_POST['publisher'];
    $rating = $_POST['rating'];
    $price = $_POST['price'];
    
    $args = array(
        'post_type' => 'book',
        'orderby' => 'date',
    );
    if($book_name){
       $args = array('s' => $book_name); 
    }
    if (($author != '') && ($publisher != '')) {
        $args['tax_query'] = array(
            'relation' => 'AND',
            array(
                'taxonomy' => 'author',
                'field' => 'id',
                'terms' => $author
            ),
            array(
                'taxonomy' => 'publisher',
                'field' => 'id',
                'terms' => $publisher
            )
        );
    } elseif (($author != '') && ($publisher == '')) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'author',
                'field' => 'id',
                'terms' => $author
            )
        );
    } elseif (($author == '') && ($publisher != '')) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'publisher',
                'field' => 'id',
                'terms' => $publisher
            )
        );
    }
    if (($rating != '') && ($price != '')) {
        $args['meta_query'] = array(
            'relation' => 'AND',
            array(
                'key' => 'books_rating',
                'value' => $rating
            ),
            array(
                'key' => 'books_price',
                'value' => array(1, $price),
                'type' => 'numeric',
                'compare' => 'BETWEEN',
            )
        );
    } elseif (($rating != '') && ($price == '')) {
        $args['meta_query'] = array(
            array(
                'key' => 'books_rating',
                'value' => $rating
            ),
        );
    } elseif (($rating == '') && ($price != '')) {
        $args['meta_query'] = array(
            array(
                'key' => 'books_price',
                'value' => array(1, $price),
                'compare' => 'BETWEEN',
            ),
        );
    }

    $query = new WP_Query($args);
    if ($query->have_posts()) :
        ?>
        <table>
            <tr>
                <th>No</th>
                <th>Book Name</th>
                <th>Price</th>
                <th>Author</th>
                <th>Publisher</th>
                <th>Rating </th>
                <?php
                $i=0;
                while ($query->have_posts()): $query->the_post(); 
                $i++;?>    
                <tr>
                    <td><?php echo $i;?></td>
                    <td><?php the_title(); ?></td>
                    <td><?php echo $price = get_post_meta(get_the_ID(), 'books_price', true); ?></td>
                    <td><?php
                        $term_list = get_the_terms($post->ID, 'author');
                        $types = '';
                        foreach ($term_list as $term_single) {
                            $types .= ucfirst($term_single->slug) . ', ';
                        }
                        $author = rtrim($types, ', ');
                        echo $author;
                        ?>
                    </td>
                    <td><?php
                        $term_list = get_the_terms($post->ID, 'publisher');
                        $types = '';
                        foreach ($term_list as $term_single) {
                            $types .= ucfirst($term_single->slug) . ', ';
                        }
                        $publisher = rtrim($types, ', ');
                        echo $publisher;
                        ?>
                    </td>
                    <td>
                        <?php $rating = get_post_meta(get_the_ID(), 'books_rating', true); ?> 
                        <span class="fa fa-star <?php if($rating >0){ echo 'checked';}?>"></span>
                        <span class="fa fa-star <?php if($rating >1){ echo 'checked';}?>"></span>
                        <span class="fa fa-star <?php if($rating >2){ echo 'checked';}?>"></span>
                        <span class="fa fa-star <?php if($rating >3){ echo 'checked';}?>"></span>
                        <span class="fa fa-star <?php if($rating >4){ echo 'checked';}?>"></span>
                    </td>
                </tr>
                <?php
            endwhile;
            wp_reset_postdata();
        else :
            echo 'No posts found';
            ?>
        </table>
    <?php
    endif;
    die();
}