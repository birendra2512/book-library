<?php

// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}

class METARls {

    public function __construct() {
        add_action('add_meta_boxes', array($this, 'books_register_meta_boxes'));
        add_action('save_post', array($this, 'books_save_meta_box'));
    }
    public function books_register_meta_boxes() {
        add_meta_box('books-1', __('Event Extra Field', 'book'), array($this,'books_display_callback'), 'book');
    }
    public function books_save_meta_box($post_id) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
            return;
        if ($parent_id = wp_is_post_revision($post_id)) {
            $post_id = $parent_id;
        }
        $fields = [
            'books_price',
            'books_rating',
        ];
        foreach ($fields as $field) {
            if (array_key_exists($field, $_POST)) {
                update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
            }
        }
    }
    /**
     * Meta box display callback.
     *
     * @param WP_Post $post Current post object.
     */
    public function books_display_callback($post) {
       $html =''; 
       $html .= '<div class="books_box">';
       $html .= '<p class="meta-options books_field">';
       $html .= '<label for="books_price">Book Price </label>';
       $html .= '<input id="books_price" type="number" name="books_price"  min="1000" max="3000" value="'.esc_attr( get_post_meta( get_the_ID(), 'books_price', true ) ).'">';
       $html .= '</p>';
       $html .= '<p class="meta-options books_field">';
       $html .= '<label for="books_rating">Star Rating </label>';
       $html .= '<input id="books_rating" type="number" name="books_rating" min="1" max="5" value="'.esc_attr( get_post_meta( get_the_ID(), 'books_rating', true ) ).'">';
       $html .= '</p>';
       $html .= '</div>';
       
       echo $html;
    }

}
function run_metarls() {

	$meta_rlsplugin = new METARls();
	return $meta_rlsplugin;

}
run_metarls();
?>