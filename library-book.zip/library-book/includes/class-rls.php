<?php

// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}

class Rls {

     public function __construct() {
        add_action('init', array($this, 'book_post_type'));
        //add_action('init', array($this, 'book_cat_taxonomy'));
       //add_action('init', array($this, 'book_tag_taxonomy'));
        add_action('init', array($this, 'book_author_taxonomy'));
        add_action('init', array($this, 'book_publisher_taxonomy'));  
    }

    public function book_post_type() {
        $book_labels = array(
            'name' => _x('Books', 'Post type general name', 'childtheme'),
            'singular_name' => _x('Book', 'Post type singular name', 'childtheme'),
            'menu_name' => _x('Books', 'Admin Menu text', 'childtheme'),
            'name_admin_bar' => _x('Book', 'Add New on Toolbar', 'childtheme'),
            'add_new' => __('Add New', 'childtheme'),
            'add_new_item' => __('Add New Book', 'childtheme'),
            'new_item' => __('New Book', 'childtheme'),
            'edit_item' => __('Edit Book', 'childtheme'),
            'view_item' => __('View Book', 'childtheme'),
            'all_items' => __('All Books', 'childtheme'),
            'search_items' => __('Search Books', 'childtheme'),
            'parent_item_colon' => __('Parent Book:', 'childtheme'),
            'not_found' => __('No Book found.', 'childtheme'),
            'not_found_in_trash' => __('No Book found in Trash.', 'childtheme'),
        );
        $book_args = array(
            'labels' => $book_labels,
            'description' => 'Book custom post type.',
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => array('slug' => 'book'),
            'capability_type' => 'post',
            'has_archive' => true,
            'hierarchical' => true,
            'menu_position' => 20,
            'supports' => array('title', 'editor', 'author', 'thumbnail'),
            'taxonomies' => array('book-category', 'publisher', 'author'),
            'show_in_rest' => true
        );
        //register post type function for register type
        register_post_type('book', $book_args);
    }

//    public function book_cat_taxonomy() {
//        register_taxonomy('book-category', 'book', array(
//            'label' => __('Category', 'childtheme'),
//            'rewrite' => array('slug' => 'book-category'),
//            'hierarchical' => true,
//        ));
//    }

    public function book_author_taxonomy() {
        register_taxonomy('author', 'book', array(
            'label' => __('Author', 'childtheme'),
            'rewrite' => array('slug' => 'author'),
            'hierarchical' => true,
        ));
    }

    public function book_publisher_taxonomy() {
        register_taxonomy('publisher', 'book', array(
            'label' => __('Publisher', 'childtheme'),
            'rewrite' => array('slug' => 'publisher'),
            'hierarchical' => true,
        ));
    }
//     public function book_tag_taxonomy() {
//        register_taxonomy('book-tag', 'book', array(
//            'label' => __('Book Tag', 'childtheme'),
//            'rewrite' => array('slug' => 'book-tag'),
//            'hierarchical' => true,
//        ));
//    }
    
    
}
function run_rls() {

	$plugin = new Rls();
	return $plugin;

}
run_rls();
?>