/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



    /* 
     * ajax js to fall back the button proper and creating product.
     * 
     */
    //filter data js
   jQuery(function ($) {
        $('#filter').submit(function () {
            var filter = $('#filter');
            $.ajax({
                url: ajax_object.ajaxurl,
                data: filter.serialize(), // form data
                type: filter.attr('method'), // POST
                beforeSend: function (xhr) {
                    filter.find('button').text('Processing...'); // changing the button label
                },
                success: function (data) {
                    filter.find('button').text('Apply filter'); // changing the button label back
                    $('#response').html(data); // insert data
                }
            });
            return false;
        });
    });


