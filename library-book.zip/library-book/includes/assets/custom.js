
jQuery(document).ready(function () {
    jQuery('#slider-container').slider({
        range: true,
        min: 1,
        max: 3000,
        values: [1, 3000],
        create: function () {
            jQuery("#amount").val("1 - 3000");
        },
        slide: function (event, ui) {
            jQuery("#amount").val(ui.values[0] + "-" + ui.values[1]);
            var mi = ui.values[0];
            var mx = ui.values[1];
            filterSystem(mi, mx);
            $('.min-value').text(mi).css({left: $('#slider-container .ui-slider-handle:nth-child(2)').css('left')});
            $('.max-value').text(mx).css({left: $('#slider-container .ui-slider-handle:last-child').css('left')});
        }
    })
});

function filterSystem(minPrice, maxPrice) {
    jQuery("li.column").hide().filter(function () {
        var price = parseInt(jQuery(this).data("price"), 10);
        return price >= minPrice && price <= maxPrice;
    }).show();
}
